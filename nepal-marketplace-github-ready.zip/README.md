# Nepal Marketplace GitHub Pages Version
This version places index.html in root.