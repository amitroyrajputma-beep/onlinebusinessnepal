# Nepal Unified Marketplace — Starter Repo

This is a starter template for the **Nepal Unified Marketplace** (local e-commerce listing + lightweight backend).
It's intended as a minimal, deployable repository you can push to GitHub and then host the frontend via GitHub Pages or deploy the backend on platforms like Render, Railway, Heroku, or Vercel (Serverless).

## What’s included
- `public/` — simple single-page frontend (HTML, CSS, JS)
- `server.js` — minimal Express backend (APIs for registration, login, products)
- `data/shops.json` — sample data store (file-based; replace with DB/Sheets later)
- `package.json` — npm scripts

## Features (starter)
- Universal registration endpoint with generated unique ID
- Basic login (no secure hashing in starter — **replace with proper auth**)
- Product upload endpoint
- Public listing endpoint
- Frontend with category & location filter UI
- Instructions to run locally and deploy

## How to run locally (development)
1. Install Node.js (v16+ recommended)
2. From repo root:
```bash
npm install
node server.js
```
3. Open http://localhost:3000

## Deployment
- To host just the frontend: push `public/` to a GitHub repo and enable **GitHub Pages** (branch `main` or `gh-pages`).
- To host backend + frontend: use Render, Railway, Heroku, or a VPS. When deploying, replace file storage (`data/shops.json`) with a proper DB (Postgres, MongoDB) or Google Sheets integration.

## Next steps (recommended)
- Replace simple file-based storage with Google Sheets integration or a database.
- Implement secure authentication (bcrypt, JWT, OAuth).
- Add Google Maps integration for addresses + geocoding.
- Add payment gateway integrations: eSewa, Khalti, bank transfers.
- Add role-based permissions and order workflow (pickup, packing, delivery, return).
- Add tests and CI.

This template is intentionally minimal — tell me which parts you want expanded (full auth, Google Sheets sync, admin dashboard, mobile app, etc.) and I will generate the code.
