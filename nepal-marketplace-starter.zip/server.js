const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const shortid = require('shortid');

const DATA_FILE = path.join(__dirname, 'data', 'shops.json');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// ensure data file
if (!fs.existsSync(DATA_FILE)) {
  fs.writeFileSync(DATA_FILE, JSON.stringify({ users: [], products: [], orders: [] }, null, 2));
}

function readData(){
  return JSON.parse(fs.readFileSync(DATA_FILE));
}
function writeData(d){
  fs.writeFileSync(DATA_FILE, JSON.stringify(d, null, 2));
}

// Register user
app.post('/api/register', (req, res) => {
  const d = readData();
  const { businessName, ownerName, email, phone, category, address, location } = req.body;
  if (!email || !businessName) return res.status(400).json({ error: 'email and businessName required' });
  if (d.users.find(u => u.email === email)) return res.status(400).json({ error: 'email already registered' });
  const id = shortid.generate();
  const username = (businessName.replace(/\s+/g,'') + id.slice(0,4)).toLowerCase();
  const password = shortid.generate().slice(0,8); // placeholder — replace with secure flow
  const user = { id, username, password, businessName, ownerName, email, phone, category, address, location, createdAt: new Date().toISOString() };
  d.users.push(user);
  writeData(d);
  res.json({ success: true, user: { id: user.id, username: user.username, password: user.password } });
});

// Simple login (demo)
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const d = readData();
  const user = d.users.find(u => u.username === username && u.password === password);
  if (!user) return res.status(401).json({ error: 'invalid credentials' });
  res.json({ success: true, user });
});

// Add product
app.post('/api/products', (req, res) => {
  const d = readData();
  const { userId, name, description, price, quantity, location, category, images } = req.body;
  if (!userId || !name) return res.status(400).json({ error: 'userId and name required' });
  const user = d.users.find(u => u.id === userId);
  if (!user) return res.status(400).json({ error: 'user not found' });
  const product = { id: shortid.generate(), userId, sellerName: user.businessName, name, description, price, quantity, location, category, images: images||[], createdAt: new Date().toISOString() };
  d.products.push(product);
  writeData(d);
  res.json({ success: true, product });
});

// Public listing with simple filters
app.get('/api/list', (req, res) => {
  const d = readData();
  let products = d.products || [];
  const { category, q, district } = req.query;
  if (category) products = products.filter(p => p.category && p.category.toLowerCase().includes(category.toLowerCase()));
  if (q) products = products.filter(p => (p.name+ ' ' + (p.description||'')).toLowerCase().includes(q.toLowerCase()));
  if (district) products = products.filter(p => p.location && p.location.district === district);
  res.json({ products, count: products.length });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('Server started on port', PORT));
